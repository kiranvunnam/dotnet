﻿namespace Manukonda_Assign4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sandybrown = new System.Windows.Forms.PictureBox();
            this.sienna = new System.Windows.Forms.PictureBox();
            this.deepPink = new System.Windows.Forms.PictureBox();
            this.blueviolet = new System.Windows.Forms.PictureBox();
            this.mediumSlateBlue = new System.Windows.Forms.PictureBox();
            this.steelblue = new System.Windows.Forms.PictureBox();
            this.powderblue = new System.Windows.Forms.PictureBox();
            this.deepskyblue = new System.Windows.Forms.PictureBox();
            this.springgreen = new System.Windows.Forms.PictureBox();
            this.darkslategray = new System.Windows.Forms.PictureBox();
            this.lemonchiffon = new System.Windows.Forms.PictureBox();
            this.darkKhaki = new System.Windows.Forms.PictureBox();
            this.fuchia = new System.Windows.Forms.PictureBox();
            this.purple = new System.Windows.Forms.PictureBox();
            this.blue = new System.Windows.Forms.PictureBox();
            this.navy = new System.Windows.Forms.PictureBox();
            this.aqua = new System.Windows.Forms.PictureBox();
            this.teal = new System.Windows.Forms.PictureBox();
            this.lime = new System.Windows.Forms.PictureBox();
            this.green = new System.Windows.Forms.PictureBox();
            this.yellow = new System.Windows.Forms.PictureBox();
            this.olive = new System.Windows.Forms.PictureBox();
            this.red = new System.Windows.Forms.PictureBox();
            this.maroon = new System.Windows.Forms.PictureBox();
            this.silver = new System.Windows.Forms.PictureBox();
            this.gray = new System.Windows.Forms.PictureBox();
            this.white = new System.Windows.Forms.PictureBox();
            this.black = new System.Windows.Forms.PictureBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.recent = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.cd = new System.Windows.Forms.ToolStripButton();
            this.drawline = new System.Windows.Forms.Button();
            this.brush = new System.Windows.Forms.Button();
            this.eraser = new System.Windows.Forms.Button();
            this.pen = new System.Windows.Forms.Button();
            this.pentool = new System.Windows.Forms.ToolTip(this.components);
            this.erasetool = new System.Windows.Forms.ToolTip(this.components);
            this.brushtool = new System.Windows.Forms.ToolTip(this.components);
            this.linetool = new System.Windows.Forms.ToolTip(this.components);
            this.savetool = new System.Windows.Forms.ToolTip(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sandybrown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sienna)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deepPink)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueviolet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mediumSlateBlue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.steelblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.powderblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deepskyblue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.springgreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.darkslategray)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lemonchiffon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.darkKhaki)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuchia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purple)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.navy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aqua)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.olive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.red)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maroon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silver)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gray)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.white)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(0, 223);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1413, 738);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.canvas_MouseDown_1);
            this.panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.canvas_MouseMove_1);
            this.panel2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.canvas_MouseUp_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.sandybrown);
            this.panel1.Controls.Add(this.sienna);
            this.panel1.Controls.Add(this.deepPink);
            this.panel1.Controls.Add(this.blueviolet);
            this.panel1.Controls.Add(this.mediumSlateBlue);
            this.panel1.Controls.Add(this.steelblue);
            this.panel1.Controls.Add(this.powderblue);
            this.panel1.Controls.Add(this.deepskyblue);
            this.panel1.Controls.Add(this.springgreen);
            this.panel1.Controls.Add(this.darkslategray);
            this.panel1.Controls.Add(this.lemonchiffon);
            this.panel1.Controls.Add(this.darkKhaki);
            this.panel1.Controls.Add(this.fuchia);
            this.panel1.Controls.Add(this.purple);
            this.panel1.Controls.Add(this.blue);
            this.panel1.Controls.Add(this.navy);
            this.panel1.Controls.Add(this.aqua);
            this.panel1.Controls.Add(this.teal);
            this.panel1.Controls.Add(this.lime);
            this.panel1.Controls.Add(this.green);
            this.panel1.Controls.Add(this.yellow);
            this.panel1.Controls.Add(this.olive);
            this.panel1.Controls.Add(this.red);
            this.panel1.Controls.Add(this.maroon);
            this.panel1.Controls.Add(this.silver);
            this.panel1.Controls.Add(this.gray);
            this.panel1.Controls.Add(this.white);
            this.panel1.Controls.Add(this.black);
            this.panel1.Location = new System.Drawing.Point(280, 20);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(528, 71);
            this.panel1.TabIndex = 3;
            // 
            // sandybrown
            // 
            this.sandybrown.BackColor = System.Drawing.Color.SandyBrown;
            this.sandybrown.Location = new System.Drawing.Point(492, 37);
            this.sandybrown.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.sandybrown.Name = "sandybrown";
            this.sandybrown.Size = new System.Drawing.Size(30, 30);
            this.sandybrown.TabIndex = 27;
            this.sandybrown.TabStop = false;
            this.sandybrown.Click += new System.EventHandler(this.black_Click);
            // 
            // sienna
            // 
            this.sienna.BackColor = System.Drawing.Color.Sienna;
            this.sienna.Location = new System.Drawing.Point(492, 5);
            this.sienna.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.sienna.Name = "sienna";
            this.sienna.Size = new System.Drawing.Size(30, 30);
            this.sienna.TabIndex = 26;
            this.sienna.TabStop = false;
            this.sienna.Click += new System.EventHandler(this.black_Click);
            // 
            // deepPink
            // 
            this.deepPink.BackColor = System.Drawing.Color.DeepPink;
            this.deepPink.Location = new System.Drawing.Point(454, 37);
            this.deepPink.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.deepPink.Name = "deepPink";
            this.deepPink.Size = new System.Drawing.Size(30, 30);
            this.deepPink.TabIndex = 25;
            this.deepPink.TabStop = false;
            this.deepPink.Click += new System.EventHandler(this.black_Click);
            // 
            // blueviolet
            // 
            this.blueviolet.BackColor = System.Drawing.Color.BlueViolet;
            this.blueviolet.Location = new System.Drawing.Point(454, 5);
            this.blueviolet.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.blueviolet.Name = "blueviolet";
            this.blueviolet.Size = new System.Drawing.Size(30, 30);
            this.blueviolet.TabIndex = 24;
            this.blueviolet.TabStop = false;
            this.blueviolet.Click += new System.EventHandler(this.black_Click);
            // 
            // mediumSlateBlue
            // 
            this.mediumSlateBlue.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.mediumSlateBlue.Location = new System.Drawing.Point(417, 37);
            this.mediumSlateBlue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mediumSlateBlue.Name = "mediumSlateBlue";
            this.mediumSlateBlue.Size = new System.Drawing.Size(30, 30);
            this.mediumSlateBlue.TabIndex = 23;
            this.mediumSlateBlue.TabStop = false;
            this.mediumSlateBlue.Click += new System.EventHandler(this.black_Click);
            // 
            // steelblue
            // 
            this.steelblue.BackColor = System.Drawing.Color.SteelBlue;
            this.steelblue.Location = new System.Drawing.Point(417, 5);
            this.steelblue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.steelblue.Name = "steelblue";
            this.steelblue.Size = new System.Drawing.Size(30, 30);
            this.steelblue.TabIndex = 22;
            this.steelblue.TabStop = false;
            this.steelblue.Click += new System.EventHandler(this.black_Click);
            // 
            // powderblue
            // 
            this.powderblue.BackColor = System.Drawing.Color.PowderBlue;
            this.powderblue.Location = new System.Drawing.Point(380, 37);
            this.powderblue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.powderblue.Name = "powderblue";
            this.powderblue.Size = new System.Drawing.Size(30, 30);
            this.powderblue.TabIndex = 21;
            this.powderblue.TabStop = false;
            this.powderblue.Click += new System.EventHandler(this.black_Click);
            // 
            // deepskyblue
            // 
            this.deepskyblue.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.deepskyblue.Location = new System.Drawing.Point(380, 5);
            this.deepskyblue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.deepskyblue.Name = "deepskyblue";
            this.deepskyblue.Size = new System.Drawing.Size(30, 30);
            this.deepskyblue.TabIndex = 20;
            this.deepskyblue.TabStop = false;
            this.deepskyblue.Click += new System.EventHandler(this.black_Click);
            // 
            // springgreen
            // 
            this.springgreen.BackColor = System.Drawing.Color.SpringGreen;
            this.springgreen.Location = new System.Drawing.Point(342, 37);
            this.springgreen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.springgreen.Name = "springgreen";
            this.springgreen.Size = new System.Drawing.Size(30, 30);
            this.springgreen.TabIndex = 19;
            this.springgreen.TabStop = false;
            this.springgreen.Click += new System.EventHandler(this.black_Click);
            // 
            // darkslategray
            // 
            this.darkslategray.BackColor = System.Drawing.Color.DarkSlateGray;
            this.darkslategray.Location = new System.Drawing.Point(342, 5);
            this.darkslategray.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.darkslategray.Name = "darkslategray";
            this.darkslategray.Size = new System.Drawing.Size(30, 30);
            this.darkslategray.TabIndex = 18;
            this.darkslategray.TabStop = false;
            this.darkslategray.Click += new System.EventHandler(this.black_Click);
            // 
            // lemonchiffon
            // 
            this.lemonchiffon.BackColor = System.Drawing.Color.LemonChiffon;
            this.lemonchiffon.Location = new System.Drawing.Point(304, 37);
            this.lemonchiffon.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lemonchiffon.Name = "lemonchiffon";
            this.lemonchiffon.Size = new System.Drawing.Size(30, 30);
            this.lemonchiffon.TabIndex = 17;
            this.lemonchiffon.TabStop = false;
            this.lemonchiffon.Click += new System.EventHandler(this.black_Click);
            // 
            // darkKhaki
            // 
            this.darkKhaki.BackColor = System.Drawing.Color.DarkKhaki;
            this.darkKhaki.Location = new System.Drawing.Point(304, 5);
            this.darkKhaki.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.darkKhaki.Name = "darkKhaki";
            this.darkKhaki.Size = new System.Drawing.Size(30, 30);
            this.darkKhaki.TabIndex = 16;
            this.darkKhaki.TabStop = false;
            this.darkKhaki.Click += new System.EventHandler(this.black_Click);
            // 
            // fuchia
            // 
            this.fuchia.BackColor = System.Drawing.Color.Fuchsia;
            this.fuchia.Location = new System.Drawing.Point(267, 37);
            this.fuchia.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.fuchia.Name = "fuchia";
            this.fuchia.Size = new System.Drawing.Size(30, 30);
            this.fuchia.TabIndex = 15;
            this.fuchia.TabStop = false;
            this.fuchia.Click += new System.EventHandler(this.black_Click);
            // 
            // purple
            // 
            this.purple.BackColor = System.Drawing.Color.Purple;
            this.purple.Location = new System.Drawing.Point(267, 5);
            this.purple.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.purple.Name = "purple";
            this.purple.Size = new System.Drawing.Size(30, 30);
            this.purple.TabIndex = 14;
            this.purple.TabStop = false;
            this.purple.Click += new System.EventHandler(this.black_Click);
            // 
            // blue
            // 
            this.blue.BackColor = System.Drawing.Color.Blue;
            this.blue.Location = new System.Drawing.Point(230, 37);
            this.blue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.blue.Name = "blue";
            this.blue.Size = new System.Drawing.Size(30, 30);
            this.blue.TabIndex = 13;
            this.blue.TabStop = false;
            this.blue.Click += new System.EventHandler(this.black_Click);
            // 
            // navy
            // 
            this.navy.BackColor = System.Drawing.Color.Navy;
            this.navy.Location = new System.Drawing.Point(230, 5);
            this.navy.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.navy.Name = "navy";
            this.navy.Size = new System.Drawing.Size(30, 30);
            this.navy.TabIndex = 12;
            this.navy.TabStop = false;
            this.navy.Click += new System.EventHandler(this.black_Click);
            // 
            // aqua
            // 
            this.aqua.BackColor = System.Drawing.Color.Aqua;
            this.aqua.Location = new System.Drawing.Point(192, 37);
            this.aqua.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.aqua.Name = "aqua";
            this.aqua.Size = new System.Drawing.Size(30, 30);
            this.aqua.TabIndex = 11;
            this.aqua.TabStop = false;
            this.aqua.Click += new System.EventHandler(this.black_Click);
            // 
            // teal
            // 
            this.teal.BackColor = System.Drawing.Color.Teal;
            this.teal.Location = new System.Drawing.Point(192, 5);
            this.teal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.teal.Name = "teal";
            this.teal.Size = new System.Drawing.Size(30, 30);
            this.teal.TabIndex = 10;
            this.teal.TabStop = false;
            this.teal.Click += new System.EventHandler(this.black_Click);
            // 
            // lime
            // 
            this.lime.BackColor = System.Drawing.Color.Lime;
            this.lime.Location = new System.Drawing.Point(154, 37);
            this.lime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lime.Name = "lime";
            this.lime.Size = new System.Drawing.Size(30, 30);
            this.lime.TabIndex = 9;
            this.lime.TabStop = false;
            this.lime.Click += new System.EventHandler(this.black_Click);
            // 
            // green
            // 
            this.green.BackColor = System.Drawing.Color.Green;
            this.green.Location = new System.Drawing.Point(154, 5);
            this.green.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.green.Name = "green";
            this.green.Size = new System.Drawing.Size(30, 30);
            this.green.TabIndex = 8;
            this.green.TabStop = false;
            this.green.Click += new System.EventHandler(this.black_Click);
            // 
            // yellow
            // 
            this.yellow.BackColor = System.Drawing.Color.Yellow;
            this.yellow.Location = new System.Drawing.Point(117, 37);
            this.yellow.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.yellow.Name = "yellow";
            this.yellow.Size = new System.Drawing.Size(30, 30);
            this.yellow.TabIndex = 7;
            this.yellow.TabStop = false;
            this.yellow.Click += new System.EventHandler(this.black_Click);
            // 
            // olive
            // 
            this.olive.BackColor = System.Drawing.Color.Olive;
            this.olive.Location = new System.Drawing.Point(117, 5);
            this.olive.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.olive.Name = "olive";
            this.olive.Size = new System.Drawing.Size(30, 30);
            this.olive.TabIndex = 6;
            this.olive.TabStop = false;
            this.olive.Click += new System.EventHandler(this.black_Click);
            // 
            // red
            // 
            this.red.BackColor = System.Drawing.Color.Red;
            this.red.Location = new System.Drawing.Point(80, 37);
            this.red.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.red.Name = "red";
            this.red.Size = new System.Drawing.Size(30, 30);
            this.red.TabIndex = 5;
            this.red.TabStop = false;
            this.red.Click += new System.EventHandler(this.black_Click);
            // 
            // maroon
            // 
            this.maroon.BackColor = System.Drawing.Color.Maroon;
            this.maroon.Location = new System.Drawing.Point(80, 5);
            this.maroon.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.maroon.Name = "maroon";
            this.maroon.Size = new System.Drawing.Size(30, 30);
            this.maroon.TabIndex = 4;
            this.maroon.TabStop = false;
            this.maroon.Click += new System.EventHandler(this.black_Click);
            // 
            // silver
            // 
            this.silver.BackColor = System.Drawing.Color.Silver;
            this.silver.Location = new System.Drawing.Point(42, 37);
            this.silver.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.silver.Name = "silver";
            this.silver.Size = new System.Drawing.Size(30, 30);
            this.silver.TabIndex = 3;
            this.silver.TabStop = false;
            this.silver.Click += new System.EventHandler(this.black_Click);
            // 
            // gray
            // 
            this.gray.BackColor = System.Drawing.Color.Gray;
            this.gray.Location = new System.Drawing.Point(42, 5);
            this.gray.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gray.Name = "gray";
            this.gray.Size = new System.Drawing.Size(30, 30);
            this.gray.TabIndex = 2;
            this.gray.TabStop = false;
            this.gray.Click += new System.EventHandler(this.black_Click);
            // 
            // white
            // 
            this.white.BackColor = System.Drawing.Color.White;
            this.white.Location = new System.Drawing.Point(4, 37);
            this.white.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.white.Name = "white";
            this.white.Size = new System.Drawing.Size(30, 30);
            this.white.TabIndex = 1;
            this.white.TabStop = false;
            this.white.Click += new System.EventHandler(this.black_Click);
            // 
            // black
            // 
            this.black.BackColor = System.Drawing.Color.Black;
            this.black.Location = new System.Drawing.Point(4, 5);
            this.black.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.black.Name = "black";
            this.black.Size = new System.Drawing.Size(30, 30);
            this.black.TabIndex = 0;
            this.black.TabStop = false;
            this.black.Click += new System.EventHandler(this.black_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton8,
            this.toolStripSeparator8,
            this.toolStripButton1,
            this.toolStripSeparator1,
            this.toolStripButton2,
            this.toolStripSeparator2,
            this.toolStripButton3,
            this.toolStripSeparator3,
            this.toolStripButton4,
            this.toolStripSeparator4,
            this.toolStripButton5,
            this.toolStripSeparator5,
            this.toolStripButton6,
            this.toolStripSeparator6,
            this.recent,
            this.toolStripSeparator7,
            this.cd});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.toolStrip1.Size = new System.Drawing.Size(1413, 31);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.BackgroundImage")));
            this.toolStripButton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton8.Text = "toolStripButton8";
            this.toolStripButton8.Click += new System.EventHandler(this.toolStripButton8_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.ToolTipText = "Save";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.ToolTipText = "Save As";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.ToolTipText = "Open";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton4.Text = "toolStripButton4";
            this.toolStripButton4.ToolTipText = "Undo";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton5.Text = "toolStripButton5";
            this.toolStripButton5.ToolTipText = "Redo";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton6.Text = "toolStripButton6";
            this.toolStripButton6.ToolTipText = "Refresh";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 31);
            // 
            // recent
            // 
            this.recent.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.recent.Image = ((System.Drawing.Image)(resources.GetObject("recent.Image")));
            this.recent.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.recent.Name = "recent";
            this.recent.Size = new System.Drawing.Size(42, 28);
            this.recent.Text = "toolStripDropDownButton1";
            this.recent.Click += new System.EventHandler(this.toolStripDropDownButton1_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 31);
            // 
            // cd
            // 
            this.cd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cd.Image = ((System.Drawing.Image)(resources.GetObject("cd.Image")));
            this.cd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cd.Name = "cd";
            this.cd.Size = new System.Drawing.Size(28, 28);
            this.cd.Text = "toolStripButton7";
            this.cd.ToolTipText = "Pick A Color";
            this.cd.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // drawline
            // 
            this.drawline.BackColor = System.Drawing.Color.Transparent;
            this.drawline.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("drawline.BackgroundImage")));
            this.drawline.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.drawline.Location = new System.Drawing.Point(202, 20);
            this.drawline.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.drawline.Name = "drawline";
            this.drawline.Size = new System.Drawing.Size(40, 40);
            this.drawline.TabIndex = 5;
            this.linetool.SetToolTip(this.drawline, "Line");
            this.drawline.UseVisualStyleBackColor = false;
            this.drawline.Click += new System.EventHandler(this.drawline_Click);
            // 
            // brush
            // 
            this.brush.BackColor = System.Drawing.Color.Transparent;
            this.brush.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("brush.BackgroundImage")));
            this.brush.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.brush.Location = new System.Drawing.Point(136, 20);
            this.brush.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.brush.Name = "brush";
            this.brush.Size = new System.Drawing.Size(40, 40);
            this.brush.TabIndex = 5;
            this.brushtool.SetToolTip(this.brush, "Brush");
            this.brush.UseVisualStyleBackColor = false;
            this.brush.Click += new System.EventHandler(this.brush_Click);
            // 
            // eraser
            // 
            this.eraser.BackColor = System.Drawing.Color.Transparent;
            this.eraser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("eraser.BackgroundImage")));
            this.eraser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.eraser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eraser.Location = new System.Drawing.Point(71, 20);
            this.eraser.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.eraser.Name = "eraser";
            this.eraser.Size = new System.Drawing.Size(40, 40);
            this.eraser.TabIndex = 6;
            this.erasetool.SetToolTip(this.eraser, "Eraser");
            this.eraser.UseVisualStyleBackColor = false;
            this.eraser.Click += new System.EventHandler(this.eraser_Click);
            // 
            // pen
            // 
            this.pen.BackColor = System.Drawing.Color.White;
            this.pen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pen.BackgroundImage")));
            this.pen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pen.Location = new System.Drawing.Point(13, 20);
            this.pen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pen.Name = "pen";
            this.pen.Size = new System.Drawing.Size(40, 40);
            this.pen.TabIndex = 7;
            this.pentool.SetToolTip(this.pen, "pen");
            this.pen.UseVisualStyleBackColor = false;
            this.pen.Click += new System.EventHandler(this.pen_Click_1);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Controls.Add(this.pen);
            this.panel3.Controls.Add(this.drawline);
            this.panel3.Controls.Add(this.eraser);
            this.panel3.Controls.Add(this.brush);
            this.panel3.Location = new System.Drawing.Point(0, 45);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1413, 93);
            this.panel3.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1413, 871);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "KKG\'s Ode to Paint";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sandybrown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sienna)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deepPink)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueviolet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mediumSlateBlue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.steelblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.powderblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deepskyblue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.springgreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.darkslategray)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lemonchiffon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.darkKhaki)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuchia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purple)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.navy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aqua)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.olive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.red)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maroon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silver)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gray)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.white)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox sandybrown;
        private System.Windows.Forms.PictureBox sienna;
        private System.Windows.Forms.PictureBox deepPink;
        private System.Windows.Forms.PictureBox blueviolet;
        private System.Windows.Forms.PictureBox mediumSlateBlue;
        private System.Windows.Forms.PictureBox steelblue;
        private System.Windows.Forms.PictureBox powderblue;
        private System.Windows.Forms.PictureBox deepskyblue;
        private System.Windows.Forms.PictureBox springgreen;
        private System.Windows.Forms.PictureBox darkslategray;
        private System.Windows.Forms.PictureBox lemonchiffon;
        private System.Windows.Forms.PictureBox darkKhaki;
        private System.Windows.Forms.PictureBox fuchia;
        private System.Windows.Forms.PictureBox purple;
        private System.Windows.Forms.PictureBox blue;
        private System.Windows.Forms.PictureBox navy;
        private System.Windows.Forms.PictureBox aqua;
        private System.Windows.Forms.PictureBox teal;
        private System.Windows.Forms.PictureBox lime;
        private System.Windows.Forms.PictureBox green;
        private System.Windows.Forms.PictureBox yellow;
        private System.Windows.Forms.PictureBox olive;
        private System.Windows.Forms.PictureBox red;
        private System.Windows.Forms.PictureBox maroon;
        private System.Windows.Forms.PictureBox silver;
        private System.Windows.Forms.PictureBox gray;
        private System.Windows.Forms.PictureBox white;
        private System.Windows.Forms.PictureBox black;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Button drawline;
        private System.Windows.Forms.Button brush;
        private System.Windows.Forms.Button eraser;
        private System.Windows.Forms.Button pen;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton cd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolTip linetool;
        private System.Windows.Forms.ToolTip brushtool;
        private System.Windows.Forms.ToolTip erasetool;
        private System.Windows.Forms.ToolTip pentool;
        private System.Windows.Forms.ToolTip savetool;
        private System.Windows.Forms.ToolStripDropDownButton recent;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}

